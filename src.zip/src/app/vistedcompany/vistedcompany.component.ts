import { Component } from '@angular/core';

@Component({
  selector: 'app-vistedcompany',
  templateUrl: './vistedcompany.component.html',
  styleUrl: './vistedcompany.component.css'
})
export class VistedcompanyComponent {
  records = [
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},
    {CompanyName:"THE LEADING SOLUTIONS",DriveCode:"	TC.30782.2024.42454	",DriveDate:"14 Mar 2024 (Confirmed)",Stream:"	MBA,Commerce,BBA",SalaryPackage:"Stipend Upto Rs. 25000 PM During 2 Month Internship Period Then CTC Rs. 6 LPA Based on Performance"},

  ];
  recordsPerPage = 10; // Number of records to display per page
  currentPage = 1; // Current page number

  // Calculate the total number of pages
  get totalPages(): number {
    return Math.ceil(this.records.length / this.recordsPerPage);
  }

  // Generate an array of page numbers
  get pagesArray(): number[] {
    return Array.from({ length: this.totalPages }, (_, index) => index + 1);
  }

  // Method to change the current page
  changePage(page: number): void {
    this.currentPage = page;
  }

  // Method to get the records for the current page
  getRecordsForCurrentPage(): any[] {
    const startIndex = (this.currentPage - 1) * this.recordsPerPage;
    const endIndex = startIndex + this.recordsPerPage;
    return this.records.slice(startIndex, endIndex);
  }
}

import { Component } from '@angular/core';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-detailsdrivemessage',
  templateUrl: './detailsdrivemessage.component.html',
  styleUrl: './detailsdrivemessage.component.css'
})
export class DetailsdrivemessageComponent {
  records = [
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},
    {subject:"Dear Student, You are eligible for COMPETETIVE EVENT of AIRTEL. Date will be notified later. Check venue through UMS. Register by Mar 29 2024 1:00PM. BEST Wishes, LPU ",date:    "3/26/2024 11:03:28 AM"},

  ];
  recordsPerPage = 5; // Number of records to display per page
  currentPage = 1; // Current page number

  // Calculate the total number of pages
  get totalPages(): number {
    return Math.ceil(this.records.length / this.recordsPerPage);
  }

  // Generate an array of page numbers
  get pagesArray(): number[] {
    return Array.from({ length: this.totalPages }, (_, index) => index + 1);
  }

  // Method to change the current page
  changePage(page: number): void {
    this.currentPage = page;
  }

  // Method to get the records for the current page
  getRecordsForCurrentPage(): any[] {
    const startIndex = (this.currentPage - 1) * this.recordsPerPage;
    const endIndex = startIndex + this.recordsPerPage;
    return this.records.slice(startIndex, endIndex);
  }

  onPageChange(event:any): void {
    this.currentPage = event.pageIndex + 1;
    this.recordsPerPage = event.pageSize;
  }

  exportToExcel(): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.records);
    const workbook: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
    XLSX.writeFile(workbook, 'drivemessage.xlsx');
  }
}

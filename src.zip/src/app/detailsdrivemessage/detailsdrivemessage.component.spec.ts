import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsdrivemessageComponent } from './detailsdrivemessage.component';

describe('DetailsdrivemessageComponent', () => {
  let component: DetailsdrivemessageComponent;
  let fixture: ComponentFixture<DetailsdrivemessageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DetailsdrivemessageComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DetailsdrivemessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

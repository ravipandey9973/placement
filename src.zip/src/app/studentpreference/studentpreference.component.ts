import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-studentpreference',
  templateUrl: './studentpreference.component.html',
  styleUrl: './studentpreference.component.css'
})
export class StudentpreferenceComponent {
  jobProfileOptions: string[] = ['Academics/Teaching', 'Application Software', 'Artificial Intelligence', 'Business Development'];
  rows: any[] = [{ skill: '', level: '', experience: '', certification: '', project: '' }];

  addRow() {
    this.rows.push({ skill: '', level: '', experience: '', certification: '', project: '' });
  }

  deleteRow(index: number) {
    this.rows.splice(index, 1);
  }

  formdata= new FormGroup({
    skill_set:new FormControl('Select',Validators.required),
    Knowledge_level:new FormControl('Select',Validators.required),
    Experience:new FormControl('Select',Validators.required)
  })
  OnSubmit() {
    console.warn('this')
  }
  Skillset: string[] = ['Select ', 'c++', 'Java', 'python', 'Web Development', 'Artificial Inteligence', 'Machine Learning', 'Robotics'];

  // Default selected option
  skilldefault: string = 'Select ';
  
}

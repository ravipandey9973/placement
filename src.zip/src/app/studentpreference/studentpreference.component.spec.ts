import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentpreferenceComponent } from './studentpreference.component';

describe('StudentpreferenceComponent', () => {
  let component: StudentpreferenceComponent;
  let fixture: ComponentFixture<StudentpreferenceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [StudentpreferenceComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(StudentpreferenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

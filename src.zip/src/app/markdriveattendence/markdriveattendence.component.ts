import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-markdriveattendence',
  templateUrl: './markdriveattendence.component.html',
  styleUrl: './markdriveattendence.component.css'
})
export class MarkdriveattendenceComponent implements OnInit {
 

  constructor() { }

  ngOnInit(): void {
 
  }

 placementForm=new FormGroup({
  selectedDrive:new FormControl('Select',Validators.required),
  selectedRound:new FormControl('Select',Validators.required)
 })

 OnSubmit()
 {
  console.warn('data submited')
 }
}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DetailsUpdationComponent } from './details-updation/details-updation.component';
import { HomeComponent } from './home/home.component';
import { DutyLeaveComponent } from './duty-leave/duty-leave.component';
import { JobofferComponent } from './joboffer/joboffer.component';
import { FamilydetailsComponent } from './familydetails/familydetails.component';
import { MarkdriveattendenceComponent } from './markdriveattendence/markdriveattendence.component';
import { PlacementcoordinatorComponent } from './placementcoordinator/placementcoordinator.component';
import { ResumeformatComponent } from './resumeformat/resumeformat.component';
import { PlacementrecordComponent } from './placementrecord/placementrecord.component';
import { DrivepdfComponent } from './drivepdf/drivepdf.component';
import { PerformancesummaryComponent } from './performancesummary/performancesummary.component';
import { StudentpreferenceComponent } from './studentpreference/studentpreference.component';
import { TestimonialComponent } from './testimonial/testimonial.component';
import { DetailsdrivemessageComponent } from './detailsdrivemessage/detailsdrivemessage.component';




const routes: Routes = [
  {path:"Home",component:HomeComponent},
  {path:"DetailsUpdation",component:DetailsUpdationComponent},
  {path:"DutyLeave",component:DutyLeaveComponent},
  {path:"FamilyDetails", component:FamilydetailsComponent},
  {path:"JobOffer",component:JobofferComponent},
  {path:"driveattendence",component:MarkdriveattendenceComponent},
  {path:"placementcoordinator",component:PlacementcoordinatorComponent},
  {path:"resumeformat",component:ResumeformatComponent},
  {path:"Placementrecord" ,component:PlacementrecordComponent},
  {path:"drivepdf",component:DrivepdfComponent},
  {path:"preference",component:StudentpreferenceComponent},
  {path:"testimonial",component:TestimonialComponent},
  {path:"drivemessage",component:DetailsdrivemessageComponent}
 


  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component } from '@angular/core';

@Component({
  selector: 'app-familydetails',
  templateUrl: './familydetails.component.html',
  styleUrl: './familydetails.component.css'
})
export class FamilydetailsComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-placementrecord',
  templateUrl: './placementrecord.component.html',
  styleUrl: './placementrecord.component.css'
})
export class PlacementrecordComponent {
 show:boolean=false;

display()
{
  this.show=true;

}
  PlacementData = [
    { companyName: 'HIGHRADIUS (Drive Id:22809)', roundNamestudentFailedToClear: 'CV short listing', lastRoundNameCleared: 'Registration' },
    { companyName: 'HIGHRADIUS (Drive Id:22809)', roundNamestudentFailedToClear: 'CV short listing', lastRoundNameCleared: 'Registration' },
    { companyName: 'HIGHRADIUS (Drive Id:22809)', roundNamestudentFailedToClear: 'CV short listing', lastRoundNameCleared: 'Registration' },
    { companyName: 'HIGHRADIUS (Drive Id:22809)', roundNamestudentFailedToClear: 'CV short listing', lastRoundNameCleared: 'Registration' },
    { companyName: 'HIGHRADIUS (Drive Id:22809)', roundNamestudentFailedToClear: 'CV short listing', lastRoundNameCleared: 'Registration' },
    { companyName: 'HIGHRADIUS (Drive Id:22809)', roundNamestudentFailedToClear: 'CV short listing', lastRoundNameCleared: 'Registration' },
    { companyName: 'HIGHRADIUS (Drive Id:22809)', roundNamestudentFailedToClear: 'CV short listing', lastRoundNameCleared: 'Registration' },
    { companyName: 'HIGHRADIUS (Drive Id:22809)', roundNamestudentFailedToClear: 'CV short listing', lastRoundNameCleared: 'Registration' },
    { companyName: 'HIGHRADIUS (Drive Id:22809)', roundNamestudentFailedToClear: 'CV short listing', lastRoundNameCleared: 'Registration' },
    { companyName: 'HIGHRADIUS (Drive Id:22809)', roundNamestudentFailedToClear: 'CV short listing', lastRoundNameCleared: 'Registration' },
    
  ];
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-performancesummary',
  templateUrl: './performancesummary.component.html',
  styleUrl: './performancesummary.component.css'
})
export class PerformancesummaryComponent {

}

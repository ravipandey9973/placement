import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PerformancesummaryComponent } from './performancesummary.component';

describe('PerformancesummaryComponent', () => {
  let component: PerformancesummaryComponent;
  let fixture: ComponentFixture<PerformancesummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PerformancesummaryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PerformancesummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

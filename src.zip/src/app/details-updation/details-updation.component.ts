import { Component } from '@angular/core';

@Component({
  selector: 'app-details-updation',
  templateUrl: './details-updation.component.html',
  styleUrl: './details-updation.component.css'
})
export class DetailsUpdationComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-crousel',
  templateUrl: './crousel.component.html',
  styleUrl: './crousel.component.css'
})
export class CrouselComponent {
  slides=[
    
    {img:"assets/tristy.gif",name:"Tristy Saha",reg:"11913789",sec:"K19GT",placed:"Amazon"}, 
    {img:"assets/rahul.gif",name:"Rahul",reg:"11910446",sec:"K18GT",placed:"Tata"}, 
    {img:"assets/vidushi.gif",name:"Vidushi",reg:"11917456",sec:"K29GT",placed:"Amazon"}, 
    {img:"assets/rohit.gif",name:"Rohit",reg:"11510456",sec:"K19ST",placed:"Google"}, 
    {img:"assets/nishant.gif",name:"Nishant",reg:"11910956",sec:"K19RT",placed:"Wipro"}, 
    {img:"assets/srijan.gif",name:"Srijan",reg:"11950456",sec:"K19GH",placed:"Jio"}, 
    {img:"assets/putti.gif",name:"Putti",reg:"11910486",sec:"K19kT",placed:"Oracle"}, 
    {img:"assets/harsh.gif",name:"Harsh",reg:"11918456",sec:"K19mT",placed:"Cognizent"}, 
    
   ];
   slideConfig = {
    "slidesToShow": 2,
    "slidesToScroll": 2,
    "autoplay": true,
    "autoplaySpeed": 1000,
    "pauseOnHover": true,
    "infinite": true,
    "vertical":true,
    "responsive": [
        {
            "breakpoint": 992,
            "settings": {
                "arrows": true,
                "infinite": true,
                "slidesToShow": 3,
                "slidesToScroll": 3
            }
        },
        {
            "breakpoint": 756,
            "settings": {
                "arrows": true,
                "infinite": true,
                "slidesToShow": 1,
                "slidesToScroll": 1
            }
        }
    ]
};

}

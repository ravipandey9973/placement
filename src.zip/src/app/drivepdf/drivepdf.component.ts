import { Component } from '@angular/core';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

@Component({
  selector: 'app-drivepdf',
  templateUrl: './drivepdf.component.html',
  styleUrl: './drivepdf.component.css'
})
export class DrivepdfComponent {
  exportToPdf() {
    const table = document.getElementById('dataTable');
    if (table) {
      html2canvas(table).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF();
        const imgProps = pdf.getImageProperties(imgData);
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (imgProps.height * pdfWidth)/ imgProps.width;
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight*0.8);
        pdf.save('table.pdf');
      });
    } else {
      console.error("Table element not found.");
    }
  }
}

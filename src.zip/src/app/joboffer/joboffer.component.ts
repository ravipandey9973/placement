import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-joboffer',
  templateUrl: './joboffer.component.html',
  styleUrl: './joboffer.component.css'
})
export class JobofferComponent {
  companies: string[] = ['Company A', 'Company B', 'Company C'];
  selectedCompany: string = '';
 
  formchecked=new FormGroup({
   
    checkbox:new FormControl('',Validators.required)
  })

  Onsubmit()
  {
    console.warn('submited')
  }


}

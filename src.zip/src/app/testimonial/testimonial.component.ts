import { Component } from '@angular/core';

@Component({
  selector: 'app-testimonial',
  templateUrl: './testimonial.component.html',
  styleUrl: './testimonial.component.css'
})
export class TestimonialComponent {
  driveDetails = [
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
   
  ];
}

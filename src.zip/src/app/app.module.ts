import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CrouselComponent } from './crousel/crousel.component';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { HomeComponent } from './home/home.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { VistedcompanyComponent } from './vistedcompany/vistedcompany.component';
import { UpcomingcompanyComponent } from './upcomingcompany/upcomingcompany.component';
import { DetailsUpdationComponent } from './details-updation/details-updation.component';
import { DutyLeaveComponent } from './duty-leave/duty-leave.component';
import { JobofferComponent } from './joboffer/joboffer.component';
import {MatPaginatorModule} from '@angular/material/paginator';
import { FamilydetailsComponent } from './familydetails/familydetails.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MarkdriveattendenceComponent } from './markdriveattendence/markdriveattendence.component';
import { PlacementcoordinatorComponent } from './placementcoordinator/placementcoordinator.component';
import { ResumeformatComponent } from './resumeformat/resumeformat.component';
import { PlacementrecordComponent } from './placementrecord/placementrecord.component';
import { PlacementsummaryComponent } from './placementsummary/placementsummary.component';
import { DrivedetailsComponent } from './drivedetails/drivedetails.component';
import { DrivepdfComponent } from './drivepdf/drivepdf.component';
import { MenuBarComponent } from './menu-bar/menu-bar.component';
import { PerformancesummaryComponent } from './performancesummary/performancesummary.component';
import { CommonModule } from '@angular/common';
import { StudentpreferenceComponent } from './studentpreference/studentpreference.component';
import { TestimonialComponent } from './testimonial/testimonial.component';
import { DetailsdrivemessageComponent } from './detailsdrivemessage/detailsdrivemessage.component';




@NgModule({
  declarations: [
    AppComponent,
    CrouselComponent,
    HomeComponent,
    VistedcompanyComponent,
    UpcomingcompanyComponent,
    DetailsUpdationComponent,
    DutyLeaveComponent,
    JobofferComponent,
    FamilydetailsComponent,
    MarkdriveattendenceComponent,
    PlacementcoordinatorComponent,
    ResumeformatComponent,
    PlacementrecordComponent,
    PlacementsummaryComponent,
    DrivedetailsComponent,
    DrivepdfComponent,
    MenuBarComponent,
    PerformancesummaryComponent,
    StudentpreferenceComponent,
    TestimonialComponent,
    DetailsdrivemessageComponent
 

    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SlickCarouselModule,
    MatPaginatorModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule
    
  
    
  ],
  providers: [
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

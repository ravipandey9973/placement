import { Component } from '@angular/core';

@Component({
  selector: 'app-drivedetails',
  templateUrl: './drivedetails.component.html',
  styleUrl: './drivedetails.component.css'
})
export class DrivedetailsComponent {
  driveDetails = [
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
    {DriveID:42614,DriveCode:'OC.15035.2023.42614',DriveType:'ON CAMPUS Drive',DriveDate:'Will be Notified Later',CompanyName:'ACXIOM CONSULTING PRIVATE LIMITED',Registered:'No (No Action)',Participated:'NA',Selected:'	NA',InternshipStatus:'NA',	OfferAccepted:'NA',DriveStatus:'Upcoming Drive'},
   
  ];
}

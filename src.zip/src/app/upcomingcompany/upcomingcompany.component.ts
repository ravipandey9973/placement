import { Component } from '@angular/core';

@Component({
  selector: 'app-upcomingcompany',
  templateUrl: './upcomingcompany.component.html',
  styleUrl: './upcomingcompany.component.css'
})
export class UpcomingcompanyComponent {

}
